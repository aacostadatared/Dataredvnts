/*
  # Create sales_pitches table

  1. New Tables
    - `sales_pitches` - Store sales pitch templates and documents
      - `id` (uuid, primary key)
      - `titulo` (text, required)
      - `descripcion` (text)
      - `contenido` (text, full pitch content)
      - `categoria` (text) - tipo de pitch (producto, servicio, etc)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `sales_pitches` table
    - Allow read/write for all users (internal tool)
*/

CREATE TABLE IF NOT EXISTS sales_pitches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo text NOT NULL,
  descripcion text DEFAULT '',
  contenido text NOT NULL,
  categoria text DEFAULT 'general',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE sales_pitches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow read pitches"
  ON sales_pitches FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow insert pitches"
  ON sales_pitches FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow update pitches"
  ON sales_pitches FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow delete pitches"
  ON sales_pitches FOR DELETE
  TO anon, authenticated
  USING (true);
