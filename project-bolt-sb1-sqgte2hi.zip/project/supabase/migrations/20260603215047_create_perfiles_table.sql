/*
  # Create perfiles (user profiles) table

  1. New Tables
    - `perfiles` - Store user profile information for DataRed CRM
      - `id` (uuid, primary key)
      - `correo` (text, unique)
      - `nombre` (text)
      - `cargo` (text)
      - `avatar_color` (text, optional)
      - `is_onboarded` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `perfiles` table
    - Add policy for anonymous and authenticated users to read
    - Add policy for users to insert their own profiles
    - Add policy for users to update their own profiles

  3. Notes
    - No foreign key to auth.users since auth flow is simulated/demo
    - Using 'correo' and 'nombre' and 'cargo' as per schema requirements
*/

CREATE TABLE IF NOT EXISTS perfiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  correo text UNIQUE NOT NULL,
  nombre text NOT NULL,
  cargo text NOT NULL,
  avatar_color text DEFAULT 'bg-blue-500',
  is_onboarded boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE perfiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow read perfiles"
  ON perfiles FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Allow insert perfiles"
  ON perfiles FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Allow update perfiles"
  ON perfiles FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow delete perfiles"
  ON perfiles FOR DELETE
  TO anon, authenticated
  USING (true);

-- Pre-seed some demo profiles
INSERT INTO perfiles (correo, nombre, cargo, avatar_color, is_onboarded)
VALUES
  ('andres@datared.com', 'Andrés García', 'Asesor Corporativo', 'bg-blue-500', true),
  ('ana@datared.com', 'Ana María López', 'Jefa de Ventas', 'bg-purple-500', true),
  ('ingeniero@datared.com', 'Carlos Rodríguez', 'Ingeniero de Sistemas', 'bg-emerald-500', true)
ON CONFLICT (correo) DO NOTHING;
