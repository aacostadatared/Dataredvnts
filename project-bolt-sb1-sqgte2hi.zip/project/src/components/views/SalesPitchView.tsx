import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { Plus, Trash2, Edit2, X, Sparkles, Copy, Check } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { cn } from '../../lib/utils';

interface SalesPitch {
  id: string;
  titulo: string;
  descripcion: string;
  contenido: string;
  categoria: string;
  created_at: string;
}

type AssistantMode = 'email' | 'follow-up' | 'proposal' | null;

export default function SalesPitchView() {
  const [pitches, setPitches] = useState<SalesPitch[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editingPitch, setEditingPitch] = useState<SalesPitch | null>(null);
  const [form, setForm] = useState({ titulo: '', descripcion: '', contenido: '', categoria: 'general' });
  const [saving, setSaving] = useState(false);

  // Assistant state
  const [selectedPitch, setSelectedPitch] = useState<SalesPitch | null>(null);
  const [assistantMode, setAssistantMode] = useState<AssistantMode>(null);
  const [assistantInput, setAssistantInput] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [generatingContent, setGeneratingContent] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    fetchPitches();
  }, []);

  async function fetchPitches() {
    const { data } = await supabase.from('sales_pitches').select('*').order('created_at', { ascending: false });
    setPitches(data || []);
    setLoading(false);
  }

  function openCreate() {
    setEditingPitch(null);
    setForm({ titulo: '', descripcion: '', contenido: '', categoria: 'general' });
    setShowForm(true);
  }

  function openEdit(pitch: SalesPitch) {
    setEditingPitch(pitch);
    setForm({
      titulo: pitch.titulo,
      descripcion: pitch.descripcion,
      contenido: pitch.contenido,
      categoria: pitch.categoria,
    });
    setShowForm(true);
  }

  async function handleSave() {
    if (!form.titulo.trim() || !form.contenido.trim()) return;
    setSaving(true);

    if (editingPitch) {
      const { data } = await supabase
        .from('sales_pitches')
        .update(form)
        .eq('id', editingPitch.id)
        .select()
        .single();
      if (data) setPitches(prev => prev.map(p => p.id === editingPitch.id ? data : p));
    } else {
      const { data } = await supabase.from('sales_pitches').insert(form).select().single();
      if (data) setPitches(prev => [data, ...prev]);
    }

    setSaving(false);
    setShowForm(false);
  }

  async function handleDelete(id: string) {
    if (confirm('¿Eliminar este pitch?')) {
      await supabase.from('sales_pitches').delete().eq('id', id);
      setPitches(prev => prev.filter(p => p.id !== id));
    }
  }

  async function generateContent() {
    if (!selectedPitch || !assistantMode || !assistantInput.trim()) return;

    setGeneratingContent(true);

    // Simulate AI generation with a realistic commercial content generator
    await new Promise(resolve => setTimeout(resolve, 1500));

    const prompts = {
      email: `Asunto: Mejora tu conectividad empresarial con DataRed

Estimado ${assistantInput}:

Le escribo en referencia a oportunidades de optimización para tu infraestructura de red.

${selectedPitch.contenido}

Cuéntame si te gustaría agendar una breve llamada para explorar cómo DataRed podría beneficiar tu operación.

Saludos,
Equipo DataRed`,

      'follow-up': `Hola ${assistantInput},

Seguimiento a nuestra última conversación sobre tus necesidades de conectividad.

Basándome en lo que compartiste:
${selectedPitch.contenido}

Tengo una propuesta específica que podría resolver tu situación. ¿Podemos agendar 15 minutos esta semana?

Disponible: Martes o Miércoles, 10-12am o 2-4pm.

Saludos,
Equipo DataRed`,

      proposal: `PROPUESTA COMERCIAL
Cliente: ${assistantInput}

ALCANCE DEL PROYECTO:
${selectedPitch.contenido}

BENEFICIOS CLAVE:
• Mejora en disponibilidad y confiabilidad
• Reducción de costos operacionales
• Soporte dedicado 24/7

PRÓXIMOS PASOS:
1. Revisión de esta propuesta
2. Validación técnica con tu equipo
3. Firma y activación

¿Tienes preguntas sobre esta propuesta?`
    };

    setGeneratedContent(prompts[assistantMode] || '');
    setGeneratingContent(false);
  }

  function copyToClipboard(text: string, id: string) {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 h-full overflow-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Centro Comercial</h1>
          <p className="text-sm text-muted-foreground mt-1">Gestiona tus pitchs de ventas y genera contenido comercial con IA</p>
        </div>
        <Button onClick={openCreate} className="bg-blue-600 hover:bg-blue-700 text-white gap-2">
          <Plus className="w-4 h-4" />
          Nuevo Pitch
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pitches List */}
        <div className="lg:col-span-2 space-y-4">
          {pitches.length === 0 ? (
            <div className="border-2 border-dashed border-border rounded-xl p-12 text-center bg-muted/30">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-lg bg-blue-50 dark:bg-blue-950/40 mb-3">
                <Plus className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-semibold text-foreground mb-1">No hay pitchs guardados</h3>
              <p className="text-sm text-muted-foreground mb-4">Crea tu primer pitch de ventas para comenzar</p>
              <Button onClick={openCreate} size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                Crear Pitch
              </Button>
            </div>
          ) : (
            pitches.map(pitch => (
              <div
                key={pitch.id}
                className={cn(
                  'p-4 rounded-lg border-2 cursor-pointer transition-all',
                  selectedPitch?.id === pitch.id
                    ? 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/30'
                    : 'border-border hover:border-blue-300 dark:hover:border-blue-700'
                )}
                onClick={() => {
                  setSelectedPitch(pitch);
                  setAssistantMode(null);
                  setGeneratedContent('');
                }}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-foreground">{pitch.titulo}</h3>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{pitch.descripcion}</p>
                  </div>
                  <div className="flex gap-1 ml-2 flex-shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openEdit(pitch);
                      }}
                      className="p-1.5 rounded hover:bg-accent transition-colors"
                      title="Editar"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-muted-foreground hover:text-foreground" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(pitch.id);
                      }}
                      className="p-1.5 rounded hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-muted-foreground hover:text-red-600" />
                    </button>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground">
                  <span className="inline-block px-2 py-1 rounded bg-muted">{pitch.categoria}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* AI Assistant Panel */}
        <div className="bg-card border border-border rounded-lg p-4 h-fit sticky top-6">
          <div className="flex items-center gap-2 mb-4 pb-4 border-b border-border">
            <Sparkles className="w-5 h-5 text-amber-500" />
            <h3 className="font-semibold text-foreground">Asistente Comercial IA</h3>
          </div>

          {!selectedPitch ? (
            <div className="text-center py-6 text-sm text-muted-foreground">
              Selecciona un pitch para generar contenido
            </div>
          ) : (
            <div className="space-y-3">
              {/* Mode Selector */}
              {!generatedContent ? (
                <>
                  <div className="space-y-2 mb-4">
                    <p className="text-xs font-semibold text-foreground mb-2">¿Qué quieres generar?</p>
                    {(['email', 'follow-up', 'proposal'] as AssistantMode[]).map(mode => (
                      <button
                        key={mode}
                        onClick={() => setAssistantMode(mode)}
                        className={cn(
                          'w-full text-left px-3 py-2 rounded-lg text-xs font-medium transition-colors border',
                          assistantMode === mode
                            ? 'bg-blue-100 text-blue-900 dark:bg-blue-900/40 dark:text-blue-300 border-blue-500'
                            : 'bg-muted text-foreground hover:bg-accent border-border'
                        )}
                      >
                        {mode === 'email' && '📧 Email en Frío'}
                        {mode === 'follow-up' && '↩️ Seguimiento'}
                        {mode === 'proposal' && '📋 Propuesta Comercial'}
                      </button>
                    ))}
                  </div>

                  {assistantMode && (
                    <div className="space-y-2">
                      <label className="text-xs font-semibold text-muted-foreground">
                        {assistantMode === 'email' && 'Nombre del prospecto'}
                        {assistantMode === 'follow-up' && 'Nombre del cliente'}
                        {assistantMode === 'proposal' && 'Nombre de la empresa'}
                      </label>
                      <Input
                        value={assistantInput}
                        onChange={(e) => setAssistantInput(e.target.value)}
                        placeholder="Ej: Juan García"
                        className="text-xs"
                      />
                      <Button
                        onClick={generateContent}
                        disabled={generatingContent || !assistantInput.trim()}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white text-xs gap-2"
                      >
                        {generatingContent ? (
                          <>
                            <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            Generando...
                          </>
                        ) : (
                          <>
                            <Sparkles className="w-3.5 h-3.5" />
                            Generar
                          </>
                        )}
                      </Button>
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-3">
                  <div className="bg-muted/50 p-3 rounded-lg max-h-60 overflow-y-auto">
                    <p className="text-xs whitespace-pre-wrap leading-relaxed text-foreground">{generatedContent}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => copyToClipboard(generatedContent, 'main')}
                      size="sm"
                      variant="outline"
                      className="flex-1 text-xs gap-1"
                    >
                      {copiedId === 'main' ? (
                        <>
                          <Check className="w-3 h-3" />
                          Copiado
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          Copiar
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={() => {
                        setGeneratedContent('');
                        setAssistantInput('');
                        setAssistantMode(null);
                      }}
                      size="sm"
                      variant="outline"
                      className="flex-1 text-xs gap-1"
                    >
                      <X className="w-3 h-3" />
                      Generar otro
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-card border border-border rounded-2xl w-full max-w-2xl shadow-2xl my-4">
            <div className="flex items-center justify-between p-6 border-b border-border">
              <h2 className="text-lg font-semibold text-foreground">
                {editingPitch ? 'Editar Pitch' : 'Nuevo Pitch de Ventas'}
              </h2>
              <button onClick={() => setShowForm(false)} className="p-2 rounded-lg hover:bg-accent transition-colors">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-6 space-y-4 max-h-[calc(100vh-200px)] overflow-y-auto">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">Título *</label>
                <Input
                  value={form.titulo}
                  onChange={(e) => setForm(f => ({ ...f, titulo: e.target.value }))}
                  placeholder="Ej: Fibra Dedicada para Empresas"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">Categoría</label>
                <select
                  value={form.categoria}
                  onChange={(e) => setForm(f => ({ ...f, categoria: e.target.value }))}
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
                >
                  <option value="general">General</option>
                  <option value="conectividad">Conectividad</option>
                  <option value="datacenter">Datacenter</option>
                  <option value="seguridad">Ciberseguridad</option>
                  <option value="soporte">Soporte</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">Descripción</label>
                <Input
                  value={form.descripcion}
                  onChange={(e) => setForm(f => ({ ...f, descripcion: e.target.value }))}
                  placeholder="Breve resumen del pitch"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-muted-foreground">Contenido Completo *</label>
                <textarea
                  value={form.contenido}
                  onChange={(e) => setForm(f => ({ ...f, contenido: e.target.value }))}
                  placeholder="Contenido detallado del pitch..."
                  rows={8}
                  className="w-full px-3 py-2 text-sm bg-background border border-input rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-ring text-foreground"
                />
              </div>
            </div>
            <div className="flex justify-end gap-3 p-6 pt-0">
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancelar</Button>
              <Button onClick={handleSave} disabled={saving} className="bg-blue-600 hover:bg-blue-700 text-white">
                {saving ? 'Guardando...' : editingPitch ? 'Actualizar' : 'Crear'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
